#!/bin/sh
cd /workspace/t177-g1-astra-63240562/repo || exit 2
export TMPDIR=/workspace/t177-g1-astra-63240562/tmp
flock -w 3600 /workspace/.heavy.lock sh -c '
git switch --detach c0bf5681edc98c5d906bc027e4b897a12d9c5a6e || exit 2
node --test --test-concurrency=1 --test-timeout=20000 --test-reporter=tap packages/adapter-pi-contact/src/memory-completion.test.ts packages/kernel/src/memory-capture.test.ts packages/kernel/src/memory-serial.test.ts packages/server/src/memory-coverage.test.ts packages/server/src/memory-reliability.test.ts > ../v5-red.tap 2>&1; echo $? > ../v5-red.exit
git switch --detach 2edec88bdb7bf271dd0b2831bc6e930425a9d931 || exit 2
npm run typecheck > ../v5-typecheck.log 2>&1; echo $? > ../v5-typecheck.exit
npm run lint > ../v5-lint.log 2>&1; echo $? > ../v5-lint.exit
node --test --test-concurrency=1 --test-timeout=120000 --test-reporter=tap packages/**/*.test.ts scripts/gates/*.test.ts > ../v5-full.tap 2>&1; echo $? > ../v5-full.exit
node scripts/t177/g1-mutations.mjs ../v5-mutations > ../v5-mutations.log 2>&1; echo $? > ../v5-mutations.exit
git diff --exit-code > ../v5-restored.log 2>&1; echo $? > ../v5-restored.exit
'
echo done > ../v5.done
