#!/bin/sh
cd /workspace/t177-astra-63240562/repo || exit 2
base64 -d ../final.bundle.b64 > ../final.bundle
git fetch ../final.bundle HEAD || exit 2
flock -w 3600 /workspace/.heavy.lock sh -c '
# 前一轮放在仓库中的 runner 是本任务 own 的未受管副本；现在采用同路径已提交版本。
rm -f scripts/t177/a-mutations.mjs
git switch --detach 10091aa629070354fbb0f8616f3d93270818d580 || exit 2
node --test --test-concurrency=1 --test-reporter=tap packages/domain/src/recovery.test.ts packages/server/src/recovery.test.ts packages/server/src/recovery-host.test.ts > ../final-red.tap 2>&1; echo $? > ../final-red.exit
git switch --detach fbd8ef8f6ed3d97ca6a736c3c6e429aa432f7e35 || exit 2
npm run typecheck > ../final-typecheck.log 2>&1; echo $? > ../final-typecheck.exit
npm run lint > ../final-lint.log 2>&1; echo $? > ../final-lint.exit
node --test --test-concurrency=1 --test-reporter=tap packages/**/*.test.ts scripts/gates/*.test.ts > ../final-full.tap 2>&1; echo $? > ../final-full.exit
node scripts/t177/a-mutations.mjs ../final-mutations > ../final-mutations.log 2>&1; echo $? > ../final-mutations.exit
git diff --exit-code > ../final-restored.log 2>&1; echo $? > ../final-restored.exit
'
echo finished > ../final.done
