#!/bin/sh
cd /workspace/t177-astra-63240562/repo || exit 2
mkdir -p ../a32-tmp
export TMPDIR=/workspace/t177-astra-63240562/a32-tmp
flock -w 3600 /workspace/.heavy.lock sh -c '
git switch --detach 77ba6af3c68905aca30c2bb9669f4bf99cebf140 || exit 2
node --test --test-concurrency=1 --test-reporter=tap packages/domain/src/recovery.test.ts packages/server/src/recovery.test.ts packages/server/src/recovery-host.test.ts > ../a32-red.tap 2>&1; echo $? > ../a32-red.exit
git switch --detach 815384d612648a7db97563f833d46d2d5723481d || exit 2
npm run typecheck > ../a32-typecheck.log 2>&1; echo $? > ../a32-typecheck.exit
npm run lint > ../a32-lint.log 2>&1; echo $? > ../a32-lint.exit
node --test --test-concurrency=1 --test-reporter=tap packages/**/*.test.ts scripts/gates/*.test.ts > ../a32-full.tap 2>&1; echo $? > ../a32-full.exit
node scripts/t177/a-mutations.mjs ../a32-mutations > ../a32-mutations.log 2>&1; echo $? > ../a32-mutations.exit
git diff --exit-code > ../a32-restored.log 2>&1; echo $? > ../a32-restored.exit
'
echo finished > ../a32.done
