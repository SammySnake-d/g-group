#!/usr/bin/env bash
set -u
R=/workspace/t177-g6-codex-20261112
cd "$R/repo" || exit 91
exec > "$R/run.log" 2>&1
date -u +%FT%TZ > "$R/started.txt"
printf 'RUNNER_HEAD='; git rev-parse HEAD
test "$(git rev-parse HEAD)" = f5f3af097109025295249a6c391fcd78f7cff025 || exit 92
node --version
git status --porcelain > "$R/source-status-before.txt"
find packages/server/proof/g6 -type f -print0 | sort -z | xargs -0 sha256sum > "$R/runner-files-before.sha256"
node --disable-warning=ExperimentalWarning packages/server/proof/g6/run.ts \
  --mode standin --groups g4on,g4off \
  --ref G1=61948a23809d03a0d9087ba1e0253235b2fda955 \
  --ref G2=e2af61506d29d177b5f8da32f54e99e28fb2924c \
  --ref G3=f6b25f8c042f20c7697f2fc204e39a9fe33f027d \
  --ref G4=7a918e6e6ea7367063292b8e0f437ac64d14468a \
  --ref G5=f881619a82f269a275d5a6cb5e823c2971c6fcb3 \
  --group-ref g4on=da066f5fee37d070785ec0ef9b2e7babebf13972 \
  --group-ref g4off=da066f5fee37d070785ec0ef9b2e7babebf13972 \
  --out "$R/standin-post-g4b" --reps 1
code=$?
printf '%s\n' "$code" > "$R/runner.exit"
sha256sum -c "$R/runner-files-before.sha256" > "$R/source-integrity.txt" 2>&1
printf '%s\n' "$?" > "$R/source-integrity.exit"
git status --porcelain > "$R/source-status-after.txt"
date -u +%FT%TZ > "$R/finished.txt"
if [ -d "$R/standin-post-g4b/raw" ]; then tar -C "$R/standin-post-g4b" -czf "$R/raw.tgz" raw; fi
cd "$R"
sha256sum raw.tgz standin-post-g4b/report.md standin-post-g4b/summary.json run.log > SHA256SUMS
exit "$code"
