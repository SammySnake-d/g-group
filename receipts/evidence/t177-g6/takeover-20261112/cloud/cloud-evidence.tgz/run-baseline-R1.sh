#!/usr/bin/env bash
set -u
R=/workspace/t177-g6-codex-20261112
cd "$R/repo" || exit 91
exec > "$R/baseline-before.log" 2>&1
test "$(git rev-parse HEAD)" = f5f3af097109025295249a6c391fcd78f7cff025 || exit 92
date -u +%FT%TZ
node --disable-warning=ExperimentalWarning packages/server/proof/g6/run.ts \
  --mode standin --groups g4on,g4off \
  --ref G1=61948a23809d03a0d9087ba1e0253235b2fda955 \
  --ref G2=e2af61506d29d177b5f8da32f54e99e28fb2924c \
  --ref G3=f6b25f8c042f20c7697f2fc204e39a9fe33f027d \
  --ref G4=7a918e6e6ea7367063292b8e0f437ac64d14468a \
  --ref G5=f881619a82f269a275d5a6cb5e823c2971c6fcb3 \
  --group-ref g4on=3218bc7dcc59465146cc9455595d81a470a618ff \
  --group-ref g4off=3218bc7dcc59465146cc9455595d81a470a618ff \
  --out "$R/standin-before-R1" --reps 1 --items R1
code=$?
printf "%s\n" "$code" > "$R/baseline-before.exit"
date -u +%FT%TZ > "$R/baseline-finished.txt"
exit "$code"
