from pathlib import Path
import subprocess,json,time,hashlib,sys,os
root=Path('/workspace/req-room-summary-20261112-v5');mem=Path('/dev/shm/gg-room-summary-20261112-resume');repo=mem/'repo'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()=='1fc0e9197d7f4e4c98b89457a752176180d17613'
command=['sudo','-n','env','GATE_SANDBOX_IMAGE=node:24-bookworm','GATE_SELFTEST_JOBS=2','TMPDIR='+str(mem/'tmp'),'PATH='+os.environ['PATH'],'/opt/node/24.21.0/bin/node','scripts/gates/run-all.ts','--self-test']
start=time.time()
with (root/'selftest-docker.log').open('w') as output:p=subprocess.run(command,cwd=repo,stdout=output,stderr=subprocess.STDOUT)
txt=(root/'selftest-docker.log').read_text();cases=[json.loads(l[len('__GATE_CASE__'):]) for l in txt.splitlines() if l.startswith('__GATE_CASE__')]
valid=p.returncode==0 and '用例 219/219' in txt and '自检通过' in txt and len(cases)==219 and all(c['pass'] for c in cases)
receipt={'head':'1fc0e9197d7f4e4c98b89457a752176180d17613','command':command,'exit_code':p.returncode,'valid':valid,'cases':len(cases),'passed':sum(c['pass'] for c in cases),'seconds':round(time.time()-start,3),'log_sha256':hashlib.sha256(txt.encode()).hexdigest(),'TMPDIR':str(mem/'tmp')}
(root/'selftest-result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True);sys.exit(0 if valid else 1)
