from pathlib import Path
import subprocess,json,time,hashlib,sys,os,re
root=Path('/workspace/req-room-summary-20261112-v5');mem=Path('/dev/shm/gg-room-summary-20261112-resume');repo=mem/'repo';red=mem/'red';env={**os.environ,'TMPDIR':str(mem/'tmp')}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert head=='1fc0e9197d7f4e4c98b89457a752176180d17613'
steps=[('red',['node','--test','--test-reporter=tap','packages/server/src/room-blocked-summary.test.ts'],red,1),('green',['node','--test','--test-reporter=tap','packages/server/src/room-blocked-summary.test.ts'],repo,0),('typecheck',['npm','run','-s','typecheck'],repo,0),('lint',['npm','run','-s','lint'],repo,0),('full',['npm','test','--silent'],repo,0),('mutations',['node','packages/server/proof/room-pending-summary-mutations.mjs',str(root/'mutations.json')],repo,0)]
results=[]
for name,command,cwd,expected in steps:
 start=time.time();(root/'status.json').write_text(json.dumps({'head':head,'running':name,'results':results},indent=2)+'\n')
 with (root/f'{name}.log').open('w') as output:p=subprocess.run(command,cwd=cwd,env=env,stdout=output,stderr=subprocess.STDOUT)
 txt=(root/f'{name}.log').read_text();valid=p.returncode==expected
 if name=='red':valid=valid and '# tests 7' in txt and '# fail 7' in txt and 'ERR_ASSERTION' in txt and '夹具必须真正走到等待用户' not in txt
 if name=='green':valid=valid and '# tests 7' in txt and '# pass 7' in txt and '# fail 0' in txt
 if name=='mutations':
  m=json.loads((root/'mutations.json').read_text()) if (root/'mutations.json').exists() else {};valid=valid and m.get('total')==8 and m.get('killed')==8
 results.append({'name':name,'command':command,'cwd':str(cwd),'expected_exit':expected,'exit_code':p.returncode,'valid':valid,'seconds':round(time.time()-start,3),'log_sha256':hashlib.sha256(txt.encode()).hexdigest()});print(json.dumps(results[-1]),flush=True)
 if not valid:break
sources=['packages/api-contract/src/entities.ts','packages/server/src/host.ts','packages/server/src/room-blocked-summary.ts','packages/server/src/room-blocked-summary.test.ts','packages/server/proof/room-pending-summary-mutations.mjs']
receipt={'head':head,'red_commit':'274e3be11e6b9d3c92c7ffc7898f601aca1e0c42','results':results,'complete':len(results)==len(steps) and all(r['valid'] for r in results),'node':subprocess.check_output(['node','--version'],text=True).strip(),'source_sha256':{f:hashlib.sha256((repo/f).read_bytes()).hexdigest() for f in sources},'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'environment':{'TMPDIR':str(mem/'tmp'),'reason':'individually owned executable tmpfs, avoid exhausted shared cloud disk; persistent receipts stay in /workspace'}}
(root/'result.json').write_text(json.dumps(receipt,indent=2)+'\n');(root/'status.json').write_text(json.dumps({'running':None,**receipt},indent=2)+'\n');sys.exit(0 if receipt['complete'] else 1)
