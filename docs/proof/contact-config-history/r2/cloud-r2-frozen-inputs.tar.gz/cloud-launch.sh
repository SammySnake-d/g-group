set -eu
python3 - <<'PR84V2_FROZEN'
from pathlib import Path
import hashlib
r=Path('/workspace/req-contact-history-r2-20261113-3dca25e9-v2-node22')
assert not (r/'queue.pid').exists(), 'existing Q02 queue must be observed, never relaunched'
assert hashlib.sha256((r/'candidate.bundle').read_bytes()).hexdigest()=='721a90b50330628a4982a0899bd82138abbe4a454b2fb4b3e5e88b81ca5435e8'
assert hashlib.sha256((r/'run.py').read_bytes()).hexdigest()=='6f6f2b122be93588972b8a832372d3d4336cef69f8e12ea7b0b4de66f2820c3f'
assert hashlib.sha256((r/'config.json').read_bytes()).hexdigest()=='94199c881f5580b077338a147c67c6af04564ca54fc5e9525ebe1793f363de94'
print('PR84V2_FROZEN_UPLOAD_VERIFIED')
PR84V2_FROZEN

set -eu
test ! -e /workspace/req-contact-history-r2-20261113-3dca25e9-v2-node22/queue.pid
setsid nohup sh -c 'echo $$ > /workspace/req-contact-history-r2-20261113-3dca25e9-v2-node22/queue.pid; echo queued > /workspace/req-contact-history-r2-20261113-3dca25e9-v2-node22/queue.state; exec flock -w 7200 /workspace/.heavy.lock sh -c '"'"'echo running > /workspace/req-contact-history-r2-20261113-3dca25e9-v2-node22/queue.state; echo $$ > /workspace/req-contact-history-r2-20261113-3dca25e9-v2-node22/runner.pid; timeout -s TERM -k 10 3800 python3 /workspace/req-contact-history-r2-20261113-3dca25e9-v2-node22/run.py > /workspace/req-contact-history-r2-20261113-3dca25e9-v2-node22/launch.log 2>&1; rc=$?; echo $rc > /workspace/req-contact-history-r2-20261113-3dca25e9-v2-node22/exit.code; echo finished > /workspace/req-contact-history-r2-20261113-3dca25e9-v2-node22/queue.state; exit $rc'"'"'' > /workspace/req-contact-history-r2-20261113-3dca25e9-v2-node22/queue.log 2>&1 < /dev/null &
pid=$!
echo DISPATCH_PID=$pid
ps -p $pid -o pid=,args=
cat /workspace/req-contact-history-r2-20261113-3dca25e9-v2-node22/queue.state 2>/dev/null || true
