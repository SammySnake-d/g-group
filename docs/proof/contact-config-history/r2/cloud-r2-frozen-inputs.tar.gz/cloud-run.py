from pathlib import Path
import os,sys,json,subprocess,time,hashlib,re,signal,tarfile
r=Path("/workspace/req-contact-history-r2-20261113-3dca25e9-v2-node22");out=r/'out';out.mkdir(exist_ok=True)
cfg=json.loads((r/'config.json').read_text());repo=r/'repo';red=r/'red';head=cfg['head'];base=cfg['base'];rows=[];errors=[];freeze={};deadline=time.monotonic()+3600
(r/'tmp').mkdir(exist_ok=True);env=dict(os.environ,TMPDIR=str(r/'tmp'),npm_config_cache=str(r/'npm-cache'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(name,cmd,cwd=repo,want=0,cap=300):
 begin=time.monotonic();timed=False
 print('command_execution '+json.dumps({'name':name,'command':cmd,'cwd':str(cwd),'head':head}),flush=True)
 with (out/(name+'.log')).open('w') as log:
  p=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=p.wait(timeout=max(1,min(cap,deadline-begin)))
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(p.pid,signal.SIGKILL);code=p.wait()
 raw=(out/(name+'.log')).read_text();row={'name':name,'command':cmd,'cwd':str(cwd),'pid':p.pid,'exit':code,'signal':-code if code<0 else None,'expected_exit':want,'timed_out':timed,'seconds':round(time.monotonic()-begin,3),'log_sha256':sha(out/(name+'.log'))};rows.append(row)
 with (out/'command-events.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
 (out/'status.json').write_text(json.dumps({'head':head,'results':rows,'errors':errors,'phase':name},indent=2)+'\n');print(json.dumps(row),flush=True)
 if code!=want or timed:raise RuntimeError(name+': unexpected execution result')
 return raw
def counts(raw,expected=None,passes=None,failures=0):
 values={}
 for k in ['tests','pass','fail','cancelled','skipped','todo']:
  found=re.findall(r'^# '+k+r' (\d+)\s*$',raw,re.M);assert len(found)==1,(k,found);values[k]=int(found[0])
 assert values['tests']>0 and values['pass']+values['fail']==values['tests']
 if expected is not None:assert values['tests']==expected,values
 if passes is not None:assert values['pass']==passes,values
 assert values['fail']==failures and all(values[k]==0 for k in ['cancelled','skipped','todo']),values
 return values
try:
 assert sha(r/'candidate.bundle')==cfg['bundle_sha256']
 import platform
 arch={'x86_64':'x64','aarch64':'arm64'}[platform.machine()];dist='node-v22.22.0-linux-'+arch;runtime=r/'runtime';runtime.mkdir(exist_ok=True)
 sums=runtime/'SHASUMS256.txt';archive=runtime/(dist+'.tar.xz');url='https://nodejs.org/dist/v22.22.0/'
 run('runtime-shasums',['curl','--fail','--location','--retry','2','--connect-timeout','20','--max-time','120',url+'SHASUMS256.txt','--output',str(sums)],r,cap=150)
 run('runtime-download',['curl','--fail','--location','--retry','2','--connect-timeout','20','--max-time','180',url+archive.name,'--output',str(archive)],r,cap=210)
 expected=[line.split()[0] for line in sums.read_text().splitlines() if line.split()[-1]==archive.name];assert len(expected)==1 and sha(archive)==expected[0],'official Node archive SHA mismatch'
 run('runtime-extract',['tar','-xJf',str(archive),'-C',str(runtime)],r,cap=60)
 env['PATH']=str(runtime/dist/'bin')+os.pathsep+env['PATH']
 node=subprocess.check_output(['node','--version'],env=env,text=True).strip();assert node=='v22.22.0',node
 (out/'task-local-node-runtime.json').write_text(json.dumps({'version':node,'architecture':arch,'binary':str(runtime/dist/'bin/node'),'official_dist_source':url+archive.name,'official_shasums_source':url+'SHASUMS256.txt','archive_sha256':sha(archive),'expected_sha256':expected[0],'official_shasums_sha256':sha(sums),'shared_node_symlink_unchanged':True,'path_scope':'this child process and its descendants only'},indent=2)+'\n')
 run('clone',['git','clone','--no-checkout','--no-hardlinks',str(r/'candidate.bundle'),str(repo)],r,cap=90)
 run('checkout',['git','checkout','-B',cfg['branch'],head],cap=60)
 run('red-worktree',['git','worktree','add','--detach',str(red),cfg['red']],cap=60)
 run('npm-green',['npm','ci','--no-audit','--no-fund'],cap=240)
 run('npm-red',['npm','ci','--no-audit','--no-fund'],red,cap=240)
 freeze={f:sha(repo/f) for f in subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0') if f and (repo/f).is_file()}
 assert freeze==cfg['source_sha256'],'tracked source differs from frozen bundle'
 for f in cfg['test_files']:assert sha(red/f)==freeze[f]
 (out/'freeze-before.json').write_text(json.dumps({'head':head,'red':cfg['red'],'base':base,'sha256':freeze,'source_files':len(freeze),'runner_sha256':sha(r/'run.py'),'config_sha256':sha(r/'config.json'),'node':node},indent=2)+'\n')
 tests=['node','--test','--test-concurrency=1','--test-timeout=120000','--test-force-exit','--test-reporter=tap',*cfg['test_files']]
 rr=run('same16-retrospective-red',tests,red,want=1,cap=150);rc=counts(rr,16,0,16)
 failed=re.findall(r'^not ok \d+ - (.+)$',rr,re.M);assert len(failed)==16 and set(failed)==set(cfg['expected_test_names'])
 assert len(re.findall(r'^\s+code: [\'\"]ERR_ASSERTION[\'\"]\s*$',rr,re.M))==16
 assert len(re.findall(r'^\s+failureType: [\'\"]testCodeFailure[\'\"]\s*$',rr,re.M))==16
 gg=run('same16-restored-green',tests,cap=150);gc=counts(gg,16,16)
 (out/'samebody-red-green.json').write_text(json.dumps({'red':cfg['red'],'green':head,'red_counts':rc,'green_counts':gc,'test_names':cfg['expected_test_names'],'same_test_bytes':True,'all_red_named_ERR_ASSERTION':True,'retrospective_not_historical_TDD':True},ensure_ascii=False,indent=2)+'\n')
 run('mutations19',['node','packages/server/proof/contact-config-history-mutations.mjs','--suite-tests=16','--out='+str(out/'mutations19')],cap=1200)
 m=json.loads((out/'mutations19'/cfg['mutation_report']).read_text())
 assert m['mutants']==19 and m['killed']==19 and m['survived']==0 and m['invalid']==0 and m['complete'] and m['sourceUnchanged'] and m['testUnchanged'] and len(m['results'])==19,m
 assert all(x['killed'] and x['classification']=='killed' and x['status']==1 and x['signal'] is None and x['error'] is None and x['timedOut'] is False and x['completeSuite'] and x['total']==16 and x['pass']+x['fail']==16 and x['copyUnchanged'] and x['sourceUnchanged'] and all(x[k]==0 for k in ['cancelled','skipped','todo']) and len([f for f in x['failures'] if f['name']==x['expectedName'] and f['assertion'] and f['testCodeFailure']])==1 for x in m['results'])
 for x in m['results']:
  assert sha(out/'mutations19'/x['tap'])==x['tapSha256'] and sha(out/'mutations19'/x['rawResult'])==x['rawResultSha256']
 production=run('production-real-host-sqlite-service',['node','packages/server/proof/contact-config-history-real.ts'],cap=90)
 assert 'PASS:真实Host/SQLite/service' in production and '未调用真实模型,未测桌面用户操作' in production
 dependency=run('dependency-regression',['node','--test','--test-concurrency=1','--test-timeout=120000','--test-force-exit','--test-reporter=tap',*cfg['dependency_test_files']],cap=180);dc=counts(dependency)
 run('typecheck',['npm','run','-s','typecheck'],cap=180)
 run('lint',['npm','run','-s','lint'],cap=120)
 full=run('full',['npm','test','--silent'],cap=1000);fc=counts(full)
 (out/'observed-counts.json').write_text(json.dumps({'dependency':dc,'full':fc,'nominal_full_tests':cfg['nominal_full_tests'],'nominal_count_is_not_acceptance_substitute':True},indent=2)+'\n')
 (out/'formal-gates-pending.json').write_text(json.dumps({'route':cfg['formal_gate_route'],'executed_in_cloud':False,'author_review_not_self_approved':True,'original_review_reject_preserved':True},indent=2)+'\n')
except Exception as e:errors.append(repr(e));print('ERROR',repr(e),flush=True)
finally:
 after={f:sha(repo/f) for f in freeze if (repo/f).is_file()};unchanged=bool(freeze) and freeze==after
 (out/'freeze-after.json').write_text(json.dumps({'head':head,'sha256':after,'source_unchanged':unchanged},indent=2)+'\n')
 result={'head':head,'red':cfg['red'],'base':base,'results':rows,'errors':errors,'source_unchanged':unchanged,'source_files':len(freeze),'acceptance_limits':cfg['known_acceptance_limits'],'cloud_behavior_complete':not errors and unchanged,'complete':False,'formal_gates_pending':True,'review_pending':True};(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 files={str(p.relative_to(out)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in out.rglob('*') if p.is_file()};(out/'file-manifest.json').write_text(json.dumps({'files':files},indent=2)+'\n')
 with tarfile.open(r/'results.tar.gz','w:gz') as t:t.add(out,arcname='out')
 print(json.dumps(result,ensure_ascii=False),flush=True);print('archive',sha(r/'results.tar.gz'),(r/'results.tar.gz').stat().st_size,flush=True)
sys.exit(0 if not errors and unchanged else 1)
