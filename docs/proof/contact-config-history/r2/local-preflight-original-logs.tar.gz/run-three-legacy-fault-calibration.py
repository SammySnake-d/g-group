from pathlib import Path
import subprocess,tempfile,shutil,json,hashlib,re,os,datetime
r=Path('/private/tmp/gg-req-contact-history-r2-resume-20261113');out=Path(__file__).resolve().parent/'three-legacy-fault-calibration';out.mkdir(exist_ok=True)
H='packages/server/src/host.ts';C='packages/server/src/contact-config-history.ts';T='packages/server/src/contact-config-history.test.ts';files=[H,C,T];frozen={p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in files};tmp=Path(tempfile.mkdtemp(prefix='gg-pr84-r2-controls-'));originals={p:(r/p).read_text() for p in [H,C]};oldtest=subprocess.check_output(['git','show','6d8123341002f0e9f397c77633c3f30a6d01a54b:'+T],cwd=r,text=True);newtest=(r/T).read_text()
faults=[('F2-stored-whole-document','CFG16',[(C,'JSON.stringify(contactConfigOf(value))','JSON.stringify(value)')]),('F6-rollback-no-transaction','CFG14',[(H,'    const changed = tx(this.db, () => {\n      const current = this.activeContactDoc(input.contactId);','    const changed = (() => {\n      const current = this.activeContactDoc(input.contactId);'),(H,'    });\n    if (!changed.replay) this.bus.emit({ type: "contact.updated", contact: changed.result.contact });','    })();\n    if (!changed.replay) this.bus.emit({ type: "contact.updated", contact: changed.result.contact });')]),('F8-keep-current-capabilities','CFG15',[(H,'      const next: ContactDoc = { ...current.value, ...historical.config };','      const next: ContactDoc = { ...current.value, ...historical.config, tools: current.value.tools, computeAssets: current.value.computeAssets, computeSlots: current.value.computeSlots, bio: current.value.bio, avatar: current.value.avatar, speakingModel: current.value.speakingModel, harness: current.value.harness };')])]
def execute(name,expected_total):
 cmd=['node','--test','--test-concurrency=1','--test-reporter=tap',T];cp=subprocess.run(cmd,cwd=tmp,capture_output=True,text=True,timeout=60);raw=cp.stdout+cp.stderr;(out/(name+'.tap')).write_text(raw);counts={k:int(re.search('^# '+k+r' (\d+)$',raw,re.M)[1]) for k in ['tests','pass','fail','cancelled','skipped','todo']};blocks=[{'name':n,'ERR_ASSERTION':"code: 'ERR_ASSERTION'" in b,'testCodeFailure':"failureType: 'testCodeFailure'" in b} for n,b in re.findall(r'^not ok \d+ - (.+)\n([\s\S]*?)(?=^# Subtest:|^1\.\.)',raw,re.M)];assert counts['tests']==expected_total and counts['pass']+counts['fail']==expected_total and not any(counts[k] for k in ['skipped','cancelled','todo']);v={'command':cmd,'exit':cp.returncode,'counts':counts,'failed':blocks,'tap_sha256':hashlib.sha256(raw.encode()).hexdigest()};print(name,json.dumps(v,ensure_ascii=False),flush=True);return v
try:
 for p in ['packages','third_party']:
  if (r/p).exists():shutil.copytree(r/p,tmp/p,symlinks=True)
 shutil.copyfile(r/'package.json',tmp/'package.json');nm=tmp/'node_modules';nm.mkdir();(nm/'@g-group').mkdir()
 for p in (r/'node_modules').iterdir():
  if p.name=='@g-group' or p.name=='.bin' or p.name.startswith('.'):continue
  (nm/p.name).symlink_to(p.resolve(),target_is_directory=p.is_dir())
 for d in (tmp/'packages').iterdir():
  p=d/'package.json'
  if p.exists():
   name=json.loads(p.read_text()).get('name','')
   if name.startswith('@g-group/'):
    link=nm/name;link.symlink_to(Path('../../packages')/d.name,target_is_directory=True);assert link.resolve()==d.resolve()
 results=[]
 for mode,text,count in [('r1-original12',oldtest,12),('r2-new16',newtest,16)]:
  (tmp/T).write_text(text)
  for path,text in originals.items():(tmp/path).write_text(text)
  baseline=execute(mode+'-baseline',count);assert baseline['exit']==0 and baseline['counts']['pass']==count
  for name,criterion,edits in faults:
   for path,text in originals.items():(tmp/path).write_text(text)
   for path,anchor,replacement in edits:
    p=tmp/path;s=p.read_text();assert s.count(anchor)==1,(name,path);p.write_text(s.replace(anchor,replacement,1))
   observed=execute(mode+'-'+name,count);designated=[x for x in observed['failed'] if x['name'].startswith(criterion+' ') and x['ERR_ASSERTION'] and x['testCodeFailure']]
   if count==12:assert observed['exit']==0 and observed['counts']['pass']==12 and not observed['failed']
   else:assert observed['exit']==1 and len(designated)==1
   results.append({'suite':mode,'fault':name,'designated_criterion':criterion,'original_survived':count==12,'designated_kill':len(designated)==1,'collateral':[x for x in observed['failed'] if not x['name'].startswith(criterion+' ')],**observed})
 assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in frozen.items())
 report={'at':datetime.datetime.now().astimezone().isoformat(),'scope':'bounded 3 legacy negative controls only; not full19 sweep/full suite','original12_source':'6d812334:'+T,'candidate16_sha256':frozen[T],'source_before_after_unchanged':True,'source_sha256':frozen,'all_three_survive_original12':True,'all_three_designated_ERR_ASSERTION_kill_new16':True,'results':results};(out/'result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
finally:shutil.rmtree(tmp)
