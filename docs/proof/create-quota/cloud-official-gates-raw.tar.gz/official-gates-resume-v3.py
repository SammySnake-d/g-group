from pathlib import Path
import os,subprocess,json,hashlib,shutil,time,traceback,tarfile
root=Path('/workspace/req-create-quota-20261113');repo=root/'gate-repo';head='e1b91fc123148d637ddfd5db0db64ba6efdba4bf';base='3cfabba2978e3b617a07c86b962eba5fd8e4d411';run=root/'official-gates-resume-v3'
steps=[];error=None;gate_exit=None;hash_output=None

def command(name,cmd,output,timeout=1800,cwd=None,env=None):
 print('command_execution '+json.dumps({'name':name,'command':cmd,'head':head}),flush=True);start=time.monotonic()
 with output.open('w') as f:p=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 result={'name':name,'command':cmd,'exit':p.returncode,'seconds':round(time.monotonic()-start,3),'output':str(output)};steps.append(result);print(json.dumps(result),flush=True);return p.returncode
try:
 run.mkdir();(run/'status.json').write_text(json.dumps({'phase':'lock_acquired','head':head,'pid':os.getpid()})+'\n')
 original=json.loads((root/'result.json').read_text());assert original['complete'] and original['head']==head
 previous=json.loads((root/'official-gates-resume-v2/result.json').read_text());assert previous['gate_exit'] is None and previous['error']=='AssertionError()'
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
 assert subprocess.run(['git','diff','--quiet'],cwd=repo).returncode==0
 identity=json.loads((root/'official-image-source-identity-v1.json').read_text());manifest=json.loads((root/'official-image-manifest-v1.json').read_text());configraw=(root/'official-image-config-v1.json').read_bytes();config=json.loads(configraw)
 assert identity['official_config_digest']=='sha256:'+hashlib.sha256(configraw).hexdigest()==manifest['config']['digest']
 assert identity['manifest_digest']=='sha256:'+hashlib.sha256((root/'official-image-manifest-v1.json').read_bytes()).hexdigest()
 assert identity['index_digest']=='sha256:'+hashlib.sha256((root/'official-image-index-v1.json').read_bytes()).hexdigest()
 docker=shutil.which('docker');sudo=shutil.which('sudo');assert docker and sudo
 p=subprocess.run([sudo,'-n',docker,'image','inspect','node:22.22.0-slim'],capture_output=True,text=True,check=True);loaded=json.loads(p.stdout)[0];assert loaded['RootFS']['Layers']==config['rootfs']['diff_ids']
 saved=run/'loaded-image-config-verification.tar';cmd=[sudo,'-n',docker,'image','save','node:22.22.0-slim'];print('command_execution '+json.dumps({'name':'verify-loaded-image-exported-content','command':cmd}),flush=True);start=time.monotonic()
 with saved.open('wb') as f,(run/'docker-save.stderr').open('w') as err:p=subprocess.run(cmd,stdout=f,stderr=err,timeout=900)
 steps.append({'name':'verify-loaded-image-exported-content','command':cmd,'exit':p.returncode,'seconds':round(time.monotonic()-start,3)});assert p.returncode==0
 with tarfile.open(saved) as t:
  exported=json.load(t.extractfile('manifest.json'));assert len(exported)==1;actual=t.extractfile(exported[0]['Config']).read()
 assert actual==configraw,'Loaded image exported OCI config is not exact official config'
 (run/'official-image-loaded-identity.json').write_text(json.dumps({'requested':'docker.io/library/node:22.22.0-slim','official_index_digest':identity['index_digest'],'official_manifest_digest':identity['manifest_digest'],'official_config_digest':manifest['config']['digest'],'loaded_exported_config_digest':'sha256:'+hashlib.sha256(actual).hexdigest(),'exported_config_bytes_equal':True,'rootfs_diff_ids_equal':True,'rootfs_diff_ids':loaded['RootFS']['Layers'],'docker_inspect_target_id':loaded['Id'],'docker_descriptor':loaded.get('Descriptor'),'verified':True,'executor_correction':'Docker containerd inspect target/index Id is not OCI config digest; v2 incorrect field assertion retained, not a gate failure. v3 checks exact exported config bytes plus rootfs diff_ids.'},indent=2)+'\n')
 layout=json.loads((root/'official-gate-dependency-layout.json').read_text());assert layout['no_external_symlinks'] and len(layout['packages'])==7
 for pkg,data in layout['packages'].items():
  for name,sha in data['tracked_file_sha256'].items():assert hashlib.sha256((Path(data['realpath'])/name).read_bytes()).hexdigest()==sha,(pkg,name)
 bindir=run/'bin';bindir.mkdir();bridge=bindir/'docker';bridge.write_text('#!/bin/sh\nexec '+sudo+' -n '+docker+' "$@"\n');bridge.chmod(0o755)
 env=os.environ.copy();env['PATH']=str(bindir)+os.pathsep+env.get('PATH','');env['GATE_SANDBOX_IMAGE']='node:22.22.0-slim';env['TMPDIR']=str(root/'tmp');env['GATE_SELFTEST_JOBS']='2'
 assert command('official-hash',['node','scripts/gates/run-all.ts','--hash','--branch','feat/create-quota','--base',base],run/'official-gate-hash.log',1800,repo,env)==0;hash_output=(run/'official-gate-hash.log').read_text().strip()
 gate_exit=command('official-mechanical-gates',['node','scripts/gates/run-all.ts','--local','--branch','feat/create-quota','--base',base],run/'official-gates.log',3600,repo,env)
 text=(run/'official-gates.log').read_text();failures=[line for line in text.splitlines() if line.startswith('✗ ')];passed=[line for line in text.splitlines() if line.startswith('✓ ')];steps[-1].update({'failures':failures,'passed':passed})
 if not(gate_exit==1 and len(failures)==1 and failures[0].startswith('✗ G-REVIEW ') and len(passed)==7):error='Official gates had failures other than the unreviewed-candidate G-REVIEW boundary'
 assert subprocess.run(['git','diff','--quiet'],cwd=repo).returncode==0
except BaseException as exc:
 error=repr(exc);traceback.print_exc()
finally:
 result={'head':head,'steps':steps,'hash_output':hash_output,'gate_exit':gate_exit,'author_gate_execution_complete':gate_exit is not None,'author_gate_expected_boundary_only':error is None,'review_complete':False,'provenance_verified':False,'error':error,'retained_behavior_result':str(root/'result.json'),'retained_original_gate_failure':str(root/'official-gates-result.json'),'retained_v2_executor_failure':str(root/'official-gates-resume-v2/result.json')}
 (run/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');(run/'status.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False),flush=True)
raise SystemExit(0 if error is None else 1)
