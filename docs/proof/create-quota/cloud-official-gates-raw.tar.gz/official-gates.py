from pathlib import Path
import os,subprocess,json,hashlib,shutil,time,traceback
root=Path('/workspace/req-create-quota-20261113');source=root/'repo';repo=root/'gate-repo';head='e1b91fc123148d637ddfd5db0db64ba6efdba4bf';base='3cfabba2978e3b617a07c86b962eba5fd8e4d411'
steps=[];error=None;gate_exit=None;hash_output=None
try:
 original=json.loads((root/'result.json').read_text());assert original['complete'] and original['head']==head,'main seven-phase run did not complete'
 subprocess.run(['git','clone','--no-hardlinks','--branch','feat/create-quota',str(source),str(repo)],check=True)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
 deps=root/'gate-deps';shutil.copytree(source/'node_modules',deps,symlinks=True)
 packages={}
 for pkg in (source/'packages').iterdir():
  f=pkg/'package.json'
  if not f.is_file():continue
  name=json.loads(f.read_text()).get('name','')
  if not name.startswith('@g-group/'):continue
  link=deps/name;assert link.is_symlink();link.unlink();shutil.copytree(pkg,link,symlinks=True,ignore=shutil.ignore_patterns('node_modules'))
  tracked=subprocess.check_output(['git','ls-files','-z','--',str(pkg.relative_to(source))],cwd=source).decode().split('\0')
  files={}
  for item in tracked:
   if not item:continue
   rel=Path(item).relative_to(pkg.relative_to(source));a=(source/item).read_bytes();b=(link/rel).read_bytes();assert a==b,item;files[str(rel)]=hashlib.sha256(a).hexdigest()
  packages[name]={'realpath':str(link.resolve()),'tracked_file_sha256':files}
 assert len(packages)==7
 for parent,dirs,files in os.walk(deps,followlinks=False):
  for name in dirs+files:
   p=Path(parent)/name
   if p.is_symlink():assert p.resolve().is_relative_to(deps.resolve()),str(p)
 (repo/'node_modules').symlink_to(deps,target_is_directory=True)
 (root/'official-gate-dependency-layout.json').write_text(json.dumps({'reason':'official Docker sandbox mounts the resolved node_modules tree only; normal npm workspace links point outside that mount. Package all seven workspace dependencies inside the permitted dependency mount, preserving every tracked byte. Known inherited G-RED mixed dependency identity remains disclosed; independent red/mutation proof uses original copy-local workspace rebinding.','packages':packages,'no_external_symlinks':True},indent=2)+'\n')
 docker=shutil.which('docker');sudo=shutil.which('sudo');assert docker and sudo
 image='node:22.22.0-slim'
 with (root/'docker-image-inspect.log').open('w') as f:p=subprocess.run([sudo,'-n',docker,'image','inspect',image],stdout=f,stderr=subprocess.STDOUT)
 steps.append({'name':'docker-image-inspect','exit':p.returncode})
 if p.returncode:
  cmd=[sudo,'-n',docker,'pull',image];print('command_execution '+json.dumps({'name':'official-gate-image-pull','command':cmd}),flush=True);start=time.time()
  with (root/'docker-image-pull.log').open('w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
  steps.append({'name':'docker-image-pull','exit':p.returncode,'seconds':round(time.time()-start,3)});assert p.returncode==0,'official image pull failed'
 bindir=root/'gate-bin';bindir.mkdir();bridge=bindir/'docker';bridge.write_text('#!/bin/sh\nexec '+sudo+' -n '+docker+' "$@"\n');bridge.chmod(0o755)
 env=os.environ.copy();env['PATH']=str(bindir)+os.pathsep+env.get('PATH','');env['GATE_SANDBOX_IMAGE']=image;env['TMPDIR']=str(root/'tmp');env['GATE_SELFTEST_JOBS']='2'
 cmd=['node','scripts/gates/run-all.ts','--hash','--branch','feat/create-quota','--base',base]
 p=subprocess.run(cmd,cwd=repo,env=env,text=True,capture_output=True,timeout=1800);(root/'official-gate-hash.log').write_text(p.stdout+p.stderr);assert p.returncode==0;hash_output=p.stdout.strip()
 cmd=['node','scripts/gates/run-all.ts','--local','--branch','feat/create-quota','--base',base]
 print('command_execution '+json.dumps({'name':'official-mechanical-gates','command':cmd,'image':image,'head':head}),flush=True);start=time.time()
 with (root/'official-gates.log').open('w') as f:p=subprocess.run(cmd,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=3600)
 gate_exit=p.returncode;text=(root/'official-gates.log').read_text();failures=[line for line in text.splitlines() if line.startswith('✗ ')];passed=[line for line in text.splitlines() if line.startswith('✓ ')]
 steps.append({'name':'official-mechanical-gates','exit':gate_exit,'seconds':round(time.time()-start,3),'failures':failures,'passed':passed})
 expected_only_review=gate_exit==1 and len(failures)==1 and failures[0].startswith('✗ G-REVIEW ') and len(passed)==7
 if not expected_only_review:error='official gates had a failure other than the unreviewed candidate G-REVIEW boundary'
 assert subprocess.run(['git','diff','--quiet'],cwd=repo).returncode==0
except BaseException as exc:
 error=repr(exc);traceback.print_exc()
finally:
 result={'head':head,'steps':steps,'hash_output':hash_output,'gate_exit':gate_exit,'author_gate_execution_complete':gate_exit is not None,'author_gate_expected_boundary_only':error is None,'review_complete':False,'provenance_verified':False,'error':error}
 (root/'official-gates-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False),flush=True)
raise SystemExit(0 if error is None else 1)
