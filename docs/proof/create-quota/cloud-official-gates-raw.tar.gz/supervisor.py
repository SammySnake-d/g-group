from pathlib import Path
import subprocess,json,os,hashlib,time
root=Path('/workspace/req-create-quota-20261113');head='e1b91fc123148d637ddfd5db0db64ba6efdba4bf'
inputs={'run.py': '87b10838a7067f5004240e07589ae4e3c3b6f6176a830f21d224c7311912be13', 'official-gates.py': 'a737501621eea37b24f752a257e26ec71356ea41277830fd0c0277f7f21381bb'}
for name,sha in inputs.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha,name
results=[]
(root/'pipeline-status.json').write_text(json.dumps({'phase':'lock_acquired','head':head,'pid':os.getpid()})+'\n')
for phase,file in [('behavior','run.py'),('official-gates','official-gates.py')]:
 (root/'pipeline-status.json').write_text(json.dumps({'phase':phase,'head':head,'pid':os.getpid(),'results':results})+'\n')
 cmd=['python3','-B','-X','pycache_prefix='+str(root/'.pycache'),'-u',str(root/file)]
 print('command_execution '+json.dumps({'phase':phase,'command':cmd,'head':head}),flush=True);start=time.time()
 p=subprocess.run(cmd,cwd=root);results.append({'phase':phase,'exit':p.returncode,'seconds':round(time.time()-start,3)})
 if p.returncode:break
complete=len(results)==2 and all(r['exit']==0 for r in results)
r={'phase':'finished','head':head,'pid':os.getpid(),'results':results,'execution_complete':complete,'review_complete':False,'provenance_verified':False}
(root/'pipeline-result.json').write_text(json.dumps(r,indent=2)+'\n');(root/'pipeline-status.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
raise SystemExit(0 if complete else 1)
