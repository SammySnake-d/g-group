from pathlib import Path
import subprocess,json,os,time,hashlib,shutil,traceback
out=Path('/workspace/req-create-quota-20261113');repo=out/'repo'
head='e1b91fc123148d637ddfd5db0db64ba6efdba4bf';red='069bbd20b7ef925e9043a54b94b4276760e09a59'
results=[];setup=[];commands=[];error=None
try:
 (out/'status.json').write_text(json.dumps({'phase':'lock_acquired','head':head,'pid':os.getpid()})+'\n')
 assert hashlib.sha256((out/'code.bundle').read_bytes()).hexdigest()=='508d2a39fb3fac90b83ffe3639755f4c0bab656cb49fd40d8dadd59bab23cbae'
 subprocess.run(['git','clone','--no-hardlinks','--branch','feat/create-quota',str(out/'code.bundle'),str(repo)],check=True)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
 assert hashlib.sha256((repo/'package-lock.json').read_bytes()).hexdigest()=='859b9037999c928e7358b113d1971ff067f651d28815347348688e754f948e68'
 os.environ['npm_config_cache']=str(out/'.npm-cache');(out/'.npm-cache').mkdir()
 install=['npm','ci','--no-audit','--no-fund']
 (out/'status.json').write_text(json.dumps({'phase':'dependency_install','head':head,'pid':os.getpid()})+'\n')
 print('command_execution '+json.dumps({'name':'dependency-install','command':install,'head':head}),flush=True);start=time.time()
 with (out/'dependency-install.log').open('w') as f:r=subprocess.run(install,cwd=repo,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
 setup.append({'name':'dependency-install','command':install,'exit':r.returncode,'seconds':round(time.time()-start,3)})
 if r.returncode:raise RuntimeError('npm ci failed; see dependency-install.log')
 assert hashlib.sha256((repo/'package-lock.json').read_bytes()).hexdigest()=='859b9037999c928e7358b113d1971ff067f651d28815347348688e754f948e68'
 identities={}
 for pkg in (repo/'packages').iterdir():
  file=pkg/'package.json'
  if not file.is_file():continue
  name=json.loads(file.read_text()).get('name','')
  if name.startswith('@g-group/'):
   link=repo/'node_modules'/name;assert link.resolve()==pkg.resolve(),(str(link),str(link.resolve()),str(pkg.resolve()))
   identities[name]={'link':str(link),'realpath':str(link.resolve()),'expected':str(pkg.resolve())}
 assert len(identities)==7
 (out/'workspace-dependency-identity.json').write_text(json.dumps(identities,indent=2)+'\n')
 test='packages/server/src/create-quota.test.ts'
 assert subprocess.check_output(['git','show',red+':'+test],cwd=repo)==(repo/test).read_bytes()
 plan=json.loads((repo/'packages/server/proof/create-quota-mutations-plan.json').read_text());assert hashlib.sha256((repo/test).read_bytes()).hexdigest()==plan['fixed_test_sha256']
 paths=['packages/api-contract/src/api.ts','packages/server/src/host.ts','packages/server/src/service.ts',test,'packages/server/proof/create-quota-mutations.mjs','packages/server/proof/create-quota-real.ts','packages/server/proof/create-quota-mutations-plan.json','package-lock.json']
 frozen={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
 (out/'source-freeze.json').write_text(json.dumps({'head':head,'red':red,'node':subprocess.check_output(['node','--version'],text=True).strip(),'input_sha256':frozen,'runner_sha256':hashlib.sha256((out/'run.py').read_bytes()).hexdigest(),'bundle_sha256':hashlib.sha256((out/'code.bundle').read_bytes()).hexdigest()},indent=2)+'\n')
 os.environ['TMPDIR']=str(out/'tmp');os.environ['GATE_SELFTEST_JOBS']='2';(out/'tmp').mkdir()
 commands=[('green',['node','--test','--test-reporter=tap',test]),('mutations',['node','packages/server/proof/create-quota-mutations.mjs']),('production',['node','packages/server/proof/create-quota-real.ts']),('q03-production-regression',['node','packages/server/proof/contact-config-history-real.ts']),('typecheck',['npm','run','-s','typecheck']),('lint',['npm','run','-s','lint']),('full',['npm','test','--silent'])]
 for name,cmd in commands:
  (out/'status.json').write_text(json.dumps({'phase':'running','head':head,'running':name,'results':results,'pid':os.getpid()},indent=2)+'\n')
  print('command_execution '+json.dumps({'name':name,'command':cmd,'head':head}),flush=True)
  start=time.time()
  with (out/(name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=repo,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
  result={'name':name,'command':cmd,'exit':r.returncode,'seconds':round(time.time()-start,3)};results.append(result);print(json.dumps(result),flush=True)
  if r.returncode:break
 assert all(hashlib.sha256((repo/p).read_bytes()).hexdigest()==v for p,v in frozen.items())
 assert subprocess.run(['git','diff','--quiet'],cwd=repo).returncode==0
except BaseException as exc:
 error=repr(exc);traceback.print_exc()
finally:
 if repo.exists():
  proof=repo/'packages/server/proof'
  for name in ['create-quota-mutations.json','create-quota-mutations-plan.json']:
   if (proof/name).exists():shutil.copy2(proof/name,out/name)
  if (proof/'create-quota-mutation-logs').exists():shutil.copytree(proof/'create-quota-mutation-logs',out/'mutant-tap',dirs_exist_ok=True)
 result={'head':head,'results':results,'setup':setup,'complete':len(setup)==1 and setup[0]['exit']==0 and len(results)==len(commands)==7 and all(x['exit']==0 for x in results) and error is None,'error':error,'pid':os.getpid()}
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');(out/'status.json').write_text(json.dumps({'phase':'finished',**result},indent=2)+'\n');print(json.dumps(result),flush=True)
raise SystemExit(0 if result['complete'] else 1)
