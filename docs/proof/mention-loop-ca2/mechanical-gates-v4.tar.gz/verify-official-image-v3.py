from pathlib import Path
import subprocess,json,hashlib,tarfile
r=Path('/workspace/req-loop-ca2-20261113');d=r/'image-acquire';out=r/'image-verified';out.mkdir(exist_ok=True)
primary=(d/'manifest.json').read_bytes();manifest=json.loads(primary);config_digest=manifest['config']['digest']
with tarfile.open(d/'official-node22.tar') as t:
 m=json.load(t.extractfile('manifest.json'));assert len(m)==1
 raw=t.extractfile(m[0]['Config']).read();assert 'sha256:'+hashlib.sha256(raw).hexdigest()==config_digest
 config=json.loads(raw)
assert m[0]['RepoTags']==['index.docker.io/library/node:i-was-a-digest']
actual=json.loads(subprocess.check_output(['sudo','-n','docker','image','inspect','node:i-was-a-digest'],text=True))[0]
assert actual['Config']==config['config']
assert actual['RootFS']['Layers']==config['rootfs']['diff_ids']
assert actual['Architecture']==config['architecture'] and actual['Os']==config['os']
assert actual['Id']==actual['Descriptor']['digest']
platform='linux/'+config['architecture'];registry_digest=subprocess.check_output([str(r/'bin/crane'),'digest','--platform='+platform,'docker.io/library/node:22.22.0-slim'],text=True,timeout=90).strip()
assert registry_digest=='sha256:'+hashlib.sha256(primary.rstrip(b'\n')).hexdigest()
subprocess.run(['sudo','-n','docker','tag','node:i-was-a-digest','node:22.22.0-slim'],check=True)
confirmed=json.loads(subprocess.check_output(['sudo','-n','docker','image','inspect','node:22.22.0-slim'],text=True))[0]
assert confirmed['Id']==actual['Id'] and confirmed['Config']==config['config'] and confirmed['RootFS']['Layers']==config['rootfs']['diff_ids']
version=subprocess.check_output(['sudo','-n','docker','run','--rm','--network','none','--user','1000:1000','node:22.22.0-slim','node','--version'],text=True,timeout=90).strip();assert version=='v22.22.0'
result={'passed':True,'route':'same official-registry image acquired by daemonless crane digest pull and Docker load; no daemon/network/group changes','source_tag':'docker.io/library/node:22.22.0-slim','registry_platform_manifest_digest':registry_digest,'official_config_digest':config_digest,'docker_descriptor_id':actual['Id'],'docker_descriptor_media_type':actual['Descriptor']['mediaType'],'runtime_config_exact':True,'rootfs_diff_ids_exact':True,'node_version':version,'official_archive_sha256':hashlib.sha256((d/'official-node22.tar').read_bytes()).hexdigest(),'crane_release':'google/go-containerregistry v0.20.3','first_daemon_pull_exit':1,'second_executor_error':'mistook source config digest for this daemon image descriptor ID; corrected binding to actual loaded reference; no image content modification'}
(out/'image.id').write_text(actual['Id']+'\n');(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
