from pathlib import Path
import json,hashlib,tarfile,subprocess
r=Path('/workspace/req-loop-ca2-20261113');d=r/'image-acquire';out=r/'image-identity-v4';out.mkdir(exist_ok=True)
primary=(d/'manifest.json').read_bytes();manifest=json.loads(primary)
with tarfile.open(d/'official-node22.tar') as t:
 m=json.load(t.extractfile('manifest.json'));assert len(m)==1
 raw=t.extractfile(m[0]['Config']).read();assert 'sha256:'+hashlib.sha256(raw).hexdigest()==manifest['config']['digest']
 config=json.loads(raw)
actual=json.loads(subprocess.check_output(['sudo','-n','docker','image','inspect','node:22.22.0-slim'],text=True))[0]
assert actual['Config']==config['config']
assert actual['RootFS']['Layers']==config['rootfs']['diff_ids']
assert actual['Architecture']==config['architecture'] and actual['Os']==config['os']
result={'identity_verified':True,'runtime_sanity_verified':False,'runtime_sanity_exit':125,'runtime_sanity_error':'official unchanged image cannot mount containerd overlayfs: invalid argument; original gate-v3 evidence retained','manifest_sha256':hashlib.sha256(primary.rstrip(b'\n')).hexdigest(),'config_digest':manifest['config']['digest'],'docker_id':actual['Id'],'config_equal':True,'rootfs_diff_ids_equal':True,'arch':actual['Architecture'],'os':actual['Os'],'declared_node_version':[s for s in config['config']['Env'] if s.startswith('NODE_VERSION=')]}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');(out/'image.id').write_text(actual['Id']+'\n');print(json.dumps(result),flush=True)
