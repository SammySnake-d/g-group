import assert from "node:assert/strict";
import { pathToFileURL } from "node:url";
const repo = process.argv[2];
assert.ok(repo);
const brief = await import(pathToFileURL(`${repo}/packages/adapter-cc-compute/src/brief.ts`).href);
const plain = await import(pathToFileURL(`${repo}/packages/adapter-cc-compute/src/plain.ts`).href);
const valid = { task: "fixture task", rules: ["fixture rule"], tools: ["Bash"], credentialRefs: ["secret://fixture"], placement: "local" };
let accesses = 0;
const getter = Object.defineProperty({}, "task", { enumerable: true, get() { accesses++; return "forbidden"; } });
const proxy = new Proxy({}, { get() { accesses++; throw Error("forbidden"); }, ownKeys() { accesses++; throw Error("forbidden"); }, getPrototypeOf() { accesses++; throw Error("forbidden"); } });
const cyclic = {}; cyclic.self = cyclic;
const sparse = []; sparse.length = 2;
const cases = [valid, null, [], { ...valid, tools: ["default"] }, { ...valid, tools: ["native_exec"] }, { ...valid, credentialRefs: ["RAW_FIXTURE"] }, { ...valid, soul: undefined }, getter, proxy];
const encode = x => {
 if (x === undefined) return { t: "undefined" };
 if (x === null || typeof x !== "object") return x;
 return { array: Array.isArray(x), nullPrototype: Object.getPrototypeOf(x) === null, frozen: Object.isFrozen(x), entries: Object.keys(x).map(k => [k, encode(x[k])]) };
};
const result = {
 tools: [...brief.CC_BUILTIN_TOOLS],
 briefs: cases.map(x => encode(brief.checkBrief(x))),
 snapshots: [{ constraintVer: 4, openQuestions: ["q"], doneSideEffects: ["written"] }, {}, { constraintVer: -1, openQuestions: [], doneSideEffects: [] }, proxy].map(x => encode(brief.checkSnapshot(x))),
 refs: ["secret://fixture", "RAW_FIXTURE", "s://x", 2, null].map(x => brief.isCredentialRef(x)),
 plain: [null, { x: undefined }, [undefined], sparse, { n: Infinity }, cyclic, getter, proxy].map(x => encode(plain.plainData(x, "fixture"))),
 guards: [null, [], {}, 1].map(x => plain.isPlainRecord(x)),
 accesses,
};
assert.equal(accesses, 0);
console.log(JSON.stringify(result, null, 2));
