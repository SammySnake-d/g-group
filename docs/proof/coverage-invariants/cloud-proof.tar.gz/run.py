from pathlib import Path
import subprocess,json,os,hashlib,re,time,sys
root=Path('/dev/shm/gg-invariants-resume-v2-20261112');repo=root/'repo';redrepo=root/'red';out=root/'out';out.mkdir(exist_ok=True)
HEAD='5cf70481c19c3d052e1da6822ac33919c3a2e1a0';BASE='4efdee0be6d161060099b5ce488e3344c70305ee';RED='a9c0ffef997b5f364fb6b725031357b4dcf93d74'
def call(cmd,cwd=None):subprocess.run(cmd,cwd=cwd,check=True)
def deps(d):
 n=d/'node_modules';n.mkdir(exist_ok=True);(n/'@g-group').mkdir(exist_ok=True)
 for p in Path('/workspace/cov-base/node_modules').iterdir():
  if p.name=='@g-group':continue
  q=n/p.name
  if not q.exists():q.symlink_to(p.resolve())
 for p in (d/'packages').iterdir():
  if (p/'package.json').is_file():
   q=n/'@g-group'/p.name
   if not q.exists():q.symlink_to(p)
   assert q.resolve()==p.resolve()
call(['git','clone','--no-hardlinks','--no-checkout','/workspace/cov-base',str(repo)])
call(['git','fetch',str(root/'candidate.bundle'),'HEAD'],repo)
call(['git','checkout','-B','feat/coverage-invariants',HEAD],repo)
call(['git','worktree','add','--detach',str(redrepo),RED],repo)
deps(repo);deps(redrepo)
tmp=root/'tmp';tmp.mkdir();os.environ['TMPDIR']=str(tmp);os.environ['MUT_OUT']=str(out/'mutations')
TEST='packages/server/src/coverage-invariants.test.ts';assert (repo/TEST).read_bytes()==(redrepo/TEST).read_bytes()
freeze={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0') if p and (repo/p).is_file()}
(out/'source-freeze.json').write_text(json.dumps({'head':HEAD,'base':BASE,'red':RED,'sha256':freeze,'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n')
results=[];error=None
def run(name,cmd,cwd=repo,want=0):
 start=time.time();log=out/(name+'.log')
 (out/'status.json').write_text(json.dumps({'head':HEAD,'running':name,'results':results},indent=2)+'\n')
 with log.open('w') as f:r=subprocess.run(cmd,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=450)
 txt=log.read_text();item={'name':name,'command':cmd,'exit_code':r.returncode,'seconds':round(time.time()-start,3),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()};results.append(item);print(json.dumps(item),flush=True)
 if r.returncode!=want:raise RuntimeError(f'{name} exit {r.returncode}, expected {want}')
 return txt
try:
 test=['node','--test','--test-concurrency=1','--test-timeout=120000','--test-force-exit','--test-reporter=tap',TEST]
 green=run('green',test);redout=run('red',test,redrepo,1)
 gp=re.findall(r'^ok \d+ - (.+)$',green,re.M);rf=re.findall(r'^not ok \d+ - (.+)$',redout,re.M)
 assert len(gp)==4 and sorted(gp)==sorted(rf) and redout.count("code: 'ERR_ASSERTION'")==4
 (out/'red-green.json').write_text(json.dumps({'green_pass':gp,'red_fail':rf,'same4':True},ensure_ascii=False,indent=2)+'\n')
 run('mutations',['node','packages/server/proof/coverage-invariants-mutations.mjs'])
 gap=run('replying-gap',['node','packages/server/proof/coverage-invariants-replying-gap.ts'],repo,1)
 assert 'ERR_ASSERTION' in gap and 'replying' in gap
 run('typecheck',['npm','run','-s','typecheck'])
 run('lint',['npm','run','-s','lint'])
 full=run('full',['npm','test','--silent'])
finally:
 unchanged=all((repo/p).is_file() and hashlib.sha256((repo/p).read_bytes()).hexdigest()==h for p,h in freeze.items())
 result={'head':HEAD,'base':BASE,'red':RED,'results':results,'source_unchanged':unchanged,'complete':len(results)==7 and all(x['exit_code']==(1 if x['name'] in ['red','replying-gap'] else 0) for x in results),'node':subprocess.check_output(['node','--version'],text=True).strip(),'known_gap':'production activity missing replying, expected red; not a product pass'}
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
