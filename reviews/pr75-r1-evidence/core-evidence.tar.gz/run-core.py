import subprocess,pathlib,json,os,time,hashlib
root=pathlib.Path('/workspace/pr75-r1-codex-5c7730f7'); repo=root/'repo'; logs=root/'logs'; logs.mkdir(exist_ok=True)
ev=root/'events.jsonl'
def run(name,cmd,cwd=None,extra=None):
 start=time.time(); rec={'event':'command_execution','name':name,'argv':cmd,'cwd':str(cwd or root),'start':start}; ev.open('a').write(json.dumps(rec)+'\n')
 with (logs/(name+'.log')).open('w') as f:
  p=subprocess.run(cmd,cwd=cwd or root,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,**(extra or {})})
 rec.update(exit=p.returncode,elapsed=round(time.time()-start,2),log=str(logs/(name+'.log'))); ev.open('a').write(json.dumps(rec)+'\n'); print(json.dumps(rec),flush=True); return p.returncode
if not repo.exists():
 if run('clone',['git','clone','--no-checkout','https://github.com/SammySnake-d/g-group.git',str(repo)]): raise SystemExit(2)
if run('checkout',['git','checkout','-b','feat/desktop-closed-loop','cb9f13e00f5ac36f6bfea47d9f4c37d0ce9398ed'],repo): raise SystemExit(2)
run('version',['node','--version'],repo)
run('freeze',['git','rev-parse','HEAD','origin/feat/desktop-files-provenance'],repo)
if run('install',['npm','ci','--no-audit','--no-fund'],repo): raise SystemExit(2)
env={'GATE_SELFTEST_JOBS':'2','GATE_MUTATION_JOBS':'2'}
run('typecheck',['npm','run','typecheck'],repo,env)
run('lint',['npm','run','lint'],repo,env)
run('test',['npm','test'],repo,env)
# 按版本化官方镜像验证门禁;权限只用任务自己的 wrapper,不改变共享配置
rc=run('docker-info',['docker','info'],repo)
if rc and run('sudo-docker-info',['sudo','-n','docker','info'],repo)==0:
 b=root/'bin'; b.mkdir(exist_ok=True); w=b/'docker'; w.write_text('#!/bin/sh\nexec sudo -n /usr/bin/docker "$@"\n'); w.chmod(0o755); env['PATH']=str(b)+':'+os.environ['PATH']; rc=0
if rc==0:
 pull=run('docker-pull',['docker','pull','node:22.22.0-slim'],repo,env)
 if pull==0: env['GATE_SANDBOX_IMAGE']='node:22.22.0-slim'
run('selftest',['npm','run','gates:selftest'],repo,env)
run('local-gates',['node','scripts/gates/run-all.ts','--local','--pr=75','--branch=feat/desktop-closed-loop','--base=origin/feat/desktop-files-provenance'],repo,env)
run('freeze-end',['git','status','--short'],repo)
(root/'core-done.json').write_text(json.dumps({'done':True,'env_keys':list(env),'finished':time.time()})+'\n')
