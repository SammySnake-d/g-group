import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import tarfile
import time

ROOT = pathlib.Path('/workspace/pr75-r1-behavior-codex-5c7730f7')
SOURCE = pathlib.Path('/workspace/pr75-r1-codex-5c7730f7/repo')
LOGS = ROOT / 'logs'
LOGS.mkdir(exist_ok=True)
ENV = {**os.environ, 'TMPDIR': str(ROOT / 'tmp'), 'GATE_SELFTEST_JOBS': '2', 'GATE_MUTATION_JOBS': '2'}
pathlib.Path(ENV['TMPDIR']).mkdir(exist_ok=True)
EVENTS = ROOT / 'events.jsonl'


def run(name, argv, cwd=SOURCE, env=None):
    start = time.time()
    rec = {'event': 'command_execution', 'name': name, 'argv': argv, 'cwd': str(cwd), 'start': start}
    with EVENTS.open('a') as f:
        f.write(json.dumps(rec) + '\n')
    with (LOGS / (name + '.log')).open('w') as f:
        p = subprocess.run(argv, cwd=cwd, env=env or ENV, stdout=f, stderr=subprocess.STDOUT)
    rec.update(exit=p.returncode, elapsed=round(time.time() - start, 2))
    with EVENTS.open('a') as f:
        f.write(json.dumps(rec) + '\n')
    print(json.dumps(rec), flush=True)
    return p.returncode


def snapshot(name, ref):
    dest = ROOT / name
    dest.mkdir()
    archive = ROOT / (name + '.tar')
    with archive.open('wb') as f:
        subprocess.run(['git', 'archive', ref], cwd=SOURCE, stdout=f, check=True)
    with tarfile.open(archive) as f:
        f.extractall(dest, filter='data')
    archive.unlink()
    nm = dest / 'node_modules'
    (nm / '@g-group').mkdir(parents=True)
    for p in (SOURCE / 'node_modules').iterdir():
        if p.name != '@g-group':
            (nm / p.name).symlink_to(p, target_is_directory=p.is_dir())
    for p in (dest / 'packages').iterdir():
        if p.is_dir():
            (nm / '@g-group' / p.name).symlink_to(p, target_is_directory=True)
    return dest


TESTS = [
    'packages/domain/src/task-unreviewed.test.ts', 'packages/domain/src/task.test.ts',
    'packages/server/src/delivery-t8a.test.ts', 'packages/server/src/delivery-plain.test.ts',
    'packages/server/src/artifacts.test.ts', 'packages/server/src/retry.test.ts',
    'packages/server/src/worktree.test.ts', 'packages/server/src/review.test.ts',
    'packages/server/src/review-actual.test.ts', 'packages/server/src/start.test.ts',
    'packages/server/src/rewind.test.ts', 'packages/server/src/lease.test.ts',
    'packages/server/src/host.test.ts',
]

red = snapshot('red-398a202c', '398a202c')
green = snapshot('green-cb9f13e0', 'cb9f13e0')
run('red-264', ['node', '--test', '--test-concurrency=2', '--test-reporter=tap', *TESTS], red)
run('green-264', ['node', '--test', '--test-concurrency=2', '--test-reporter=tap', *TESTS], green)
run('resident-mutations', ['node', 'packages/adapter-cc-compute/proof/resident-complete-mutations.mjs'], green)
run('review-mutations', ['node', 'packages/server/proof/cross-vendor-review-mutations.mjs'], green)

# 独立构造八个中性门禁反例。夹具不冒充本轮真实作者/审查来源。
fixture = ROOT / 'neutral-gate-fixture'
fixture.mkdir()


def put(rel, text):
    p = fixture / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text)


def git(*argv):
    return subprocess.check_output(['git', '-c', 'core.hooksPath=/dev/null', *argv], cwd=fixture, text=True).strip()


def commit(msg):
    git('add', '-A')
    git('-c', 'user.name=NeutralFixture', '-c', 'user.email=neutral@invalid', 'commit', '-qm', msg)
    return git('rev-parse', 'HEAD')


git('init', '-q', '-b', 'main')
put('docs/spec/验收文档-v0.1.md', '# 中性夹具\nAC-28\n')
put('packages/probe/package.json', json.dumps({'name': '@neutral/probe', 'gGroup': {'layer': 'domain'}}))
put('packages/kernel/package.json', json.dumps({'name': '@neutral/kernel', 'gGroup': {'layer': 'kernel'}}))
put('.github/workflows/trusted-gates.yml', 'name: trusted-gates\non: pull_request_target\npermissions: { contents: read }\njobs:\n  trusted-gates:\n    runs-on: ubuntu-latest\n    steps: [{ run: "true" }]\n')
commit('中性基线')
git('checkout', '-qb', 'feat/neutral-pr75')
SOURCE_REL = 'packages/probe/src/neutral.ts'
TEST_REL = 'packages/probe/src/neutral.test.ts'
TEST = '''import assert from 'node:assert/strict';
import { test } from 'node:test';
import { neutral } from './neutral.ts';
test('中性输入有确定结果', () => { assert.equal(neutral(8), 9); });
'''
put(SOURCE_REL, 'export function neutral(_n: number) { return 0; }\n')
put(TEST_REL, TEST)
red_sha = commit('中性红规格')
put(SOURCE_REL, 'export function neutral(n: number) { return n + 1; }\n')
put('packages/probe/proof/neutral.txt', 'NEUTRAL_FIXTURE_NO_CREDENTIALS\n')
commit('中性绿实现')
RECEIPT = 'receipts/feat-neutral-pr75.json'
receipt = {
    'slice': '只用于审查门禁的中性夹具',
    'acceptance': [{'id': 'AC-28', 'status': '通过', 'evidence': 'packages/probe/proof/neutral.txt'}],
    'author': {'agent': 'claude', 'session': 'claude:neutral-author', 'model': 'claude-opus-5-5'},
    'review': {'agent': 'codex', 'session': 'codex:neutral-review', 'model': 'gpt-6.1-sol', 'verdict': 'approve', 'reviewed_hash': '', 'notes': 'NEUTRAL_FIXTURE_NO_CREDENTIALS'},
    'red': {'commit': red_sha}, 'unverifiable': 'AC-28：中性夹具，无真实会话来源', 'waiver': None,
}
put(RECEIPT, json.dumps(receipt, ensure_ascii=False))
git('add', '-A')
cli = ['node', str(SOURCE / 'scripts/gates/run-all.ts'), '--repo', str(fixture), '--base', 'main', '--branch', 'feat/neutral-pr75', '--pr', '75']
receipt['review']['reviewed_hash'] = subprocess.check_output([*cli, '--hash'], cwd=SOURCE, env=ENV, text=True).strip()
put(RECEIPT, json.dumps(receipt, ensure_ascii=False))
good = commit('中性收据')
gate_env = {**ENV, 'GATE_SANDBOX_IMAGE': 'node:22.22.0-slim', 'PATH': '/workspace/pr75-r1-codex-5c7730f7/bin:' + ENV['PATH'], 'MIRASIM_SESSIONS': str(ROOT / 'empty-sessions')}
run('gate-positive', cli, SOURCE, gate_env)
baseline = {p.relative_to(fixture).as_posix(): p.read_bytes() for p in fixture.rglob('*') if p.is_file() and '.git' not in p.parts}


def restore():
    for p in fixture.rglob('*'):
        if p.is_file() and '.git' not in p.parts and p.relative_to(fixture).as_posix() not in baseline:
            p.unlink()
    for rel, data in baseline.items():
        p = fixture / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)


cases = [
    ('G-TRACE', lambda: (fixture / RECEIPT).unlink()),
    ('G-REVIEW', lambda: put(RECEIPT, json.dumps({**receipt, 'review': {**receipt['review'], 'verdict': 'reject'}}))),
    ('G-RED', lambda: put(RECEIPT, json.dumps({**receipt, 'red': {'commit': '1111111111111111111111111111111111111111'}}))),
    ('G-STUB', lambda: put(TEST_REL, "import assert from 'node:assert/strict';\nimport {test} from 'node:test';\ntest('中性恒真不能替代行为', () => { assert.equal(8,8); });\n")),
    ('G-TAUTO', lambda: put(TEST_REL, TEST.replace('neutral(8), 9', 'neutral(8), neutral(8)'))),
    ('G-WORKFLOW', lambda: put('.github/workflows/neutral.yml', 'name: neutral\non: push\npermissions: write-all\njobs:\n  neutral:\n    runs-on: ubuntu-latest\n    steps: [{ run: "true" }]\n')),
    ('G-LAYER', lambda: put('packages/probe/package.json', json.dumps({'name': '@neutral/probe', 'gGroup': {'layer': 'domain'}, 'dependencies': {'@neutral/kernel': '*'}}))),
    ('G-PROVENANCE', lambda: None),
]
verdicts = []
for gate, mutate in cases:
    restore()
    mutate()
    # 内容差异必须真的进入 git diff，收据 hash 同步后只让目标守卫决定。
    commit('中性门禁反例 ' + gate)
    receipt_now = json.loads((fixture / RECEIPT).read_text()) if (fixture / RECEIPT).exists() else None
    if receipt_now and receipt_now.get('review'):
        receipt_now['review']['reviewed_hash'] = subprocess.check_output([*cli, '--hash'], cwd=SOURCE, env=ENV, text=True).strip()
        put(RECEIPT, json.dumps(receipt_now, ensure_ascii=False))
    rc = run('negative-' + gate, [*cli, *(['--local'] if gate == 'G-PROVENANCE' else [])], SOURCE, gate_env)
    text = (LOGS / ('negative-' + gate + '.log')).read_text()
    verdicts.append({'gate': gate, 'exit': rc, 'target_rejected': ('✗ ' + gate + ' ') in text})
(ROOT / 'gate-negative-results.json').write_text(json.dumps(verdicts, ensure_ascii=False, indent=2) + '\n')
run('freeze-source-end', ['git', 'status', '--short'])
(ROOT / 'behavior-done.json').write_text(json.dumps({'done': True, 'finished': time.time()}) + '\n')
