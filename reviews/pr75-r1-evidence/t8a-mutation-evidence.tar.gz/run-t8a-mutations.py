import json
import os
import pathlib
import re
import shutil
import subprocess
import time

ROOT = pathlib.Path('/workspace/pr75-r1-t8a-mut-ui-codex-5c7730f7')
SOURCE = pathlib.Path('/workspace/pr75-r1-ui-codex-5c7730f7/repo')
LOGS = ROOT / 'logs'
LOGS.mkdir(exist_ok=True)
TESTS = ['packages/domain/src/task-unreviewed.test.ts', 'packages/server/src/delivery-t8a.test.ts', 'packages/server/src/retry.test.ts', 'packages/server/src/review-actual.test.ts']
mutants = [
    ('无审查仍停在T5', 'packages/server/src/host.ts', 'else if (req) this.deliverUnreviewedTx(a.taskId, req);', 'else if (req) void req;', 'Q09 A0 私聊没有审查人'),
    ('本人验收不记豁免', 'packages/domain/src/task.ts', 't.reviewGate === "none" ? "waived-by-user" : t.reviewGate', 't.reviewGate', 'Q09 A2 提出者本人验收没经审查的交付'),
    ('非提出者也可验收', 'packages/domain/src/task.ts', 'if (as(e, "UserAccept").by !== t.requester) return no(', 'if (false && as(e, "UserAccept").by !== t.requester) return no(', 'Q09 A2 阴性 他人验收被拒'),
    ('无审查过期轮次不校验', 'packages/domain/src/task.ts', 'const ev = as(e, "ReviewUnavailable");\n  if (ev.round !== t.reviewRound || ev.commit !== t.reviewedCommit || ev.constraintVer !== t.constraintVer) return ok(t);', 'const ev = as(e, "ReviewUnavailable");\n  void ev;', 'Q09 A0 过期的无审查结论被忽略'),
    ('F13不再拒绝生产厂商', 'packages/domain/src/task.ts', 'if (!producers.has(reviewer)) return "compliant";', 'if (reviewer !== "unknown") return "compliant";', 'F13 半途换模'),
    ('实际审查模型不核对', 'packages/server/src/host.ts', 'const bad = reviewModelProblem(actual, t.producerModels);', 'const bad = null;', 'AC-26 审查 Compute 回报的实际模型与生产厂商同源'),
]


def copy(name):
    d = ROOT / name
    d.mkdir()
    shutil.copytree(SOURCE / 'packages', d / 'packages', ignore=shutil.ignore_patterns('proof'))
    shutil.copy2(SOURCE / 'package.json', d / 'package.json')
    nm = d / 'node_modules'
    (nm / '@g-group').mkdir(parents=True)
    for p in (SOURCE / 'node_modules').iterdir():
        if p.name != '@g-group':
            (nm / p.name).symlink_to(p, target_is_directory=p.is_dir())
    for p in (d / 'packages').iterdir():
        (nm / '@g-group' / p.name).symlink_to(p, target_is_directory=True)
    return d


def run(name, d):
    cmd = ['node', '--test', '--test-concurrency=1', '--test-reporter=tap', *TESTS]
    started = time.time()
    with (LOGS / (name + '.log')).open('w') as f:
        p = subprocess.run(cmd, cwd=d, stdout=f, stderr=subprocess.STDOUT, timeout=180)
    text = (LOGS / (name + '.log')).read_text()
    names = re.findall(r'^not ok \d+ - (.+)$', text, re.M)
    counts = {k: int(v) for k, v in re.findall(r'^# (tests|pass|fail|skipped|cancelled|todo) (\d+)$', text, re.M)}
    rec = {'event': 'command_execution', 'name': name, 'argv': cmd, 'cwd': str(d), 'exit': p.returncode, 'seconds': round(time.time() - started, 2), 'counts': counts, 'failed': names}
    with (ROOT / 'events.jsonl').open('a') as f:
        f.write(json.dumps(rec, ensure_ascii=False) + '\n')
    print(json.dumps(rec, ensure_ascii=False), flush=True)
    return rec


base = run('clean', copy('clean'))
results = []
for i, (name, rel, before, after, target) in enumerate(mutants):
    d = copy('mut-' + str(i))
    p = d / rel
    src = p.read_text()
    hits = src.count(before)
    if hits != 1:
        results.append({'name': name, 'hits': hits, 'killed': False})
        continue
    p.write_text(src.replace(before, after))
    rec = run('mut-' + str(i), d)
    complete = rec['counts'].get('tests') == base['counts'].get('tests') and all(rec['counts'].get(k, 0) == 0 for k in ['skipped', 'cancelled', 'todo'])
    killed = complete and rec['exit'] == 1 and any(target in n for n in rec['failed'])
    results.append({'name': name, 'hits': hits, 'complete': complete, 'target': target, 'killed': killed})
(ROOT / 'mutation-results.json').write_text(json.dumps({'baseline': base, 'mutants': results}, ensure_ascii=False, indent=2) + '\n')
(ROOT / 'done.json').write_text(json.dumps({'done': True, 'at': time.time()}) + '\n')
