import subprocess,pathlib,json,os,time,hashlib
root=pathlib.Path('/workspace/pr75-r1-ui-codex-5c7730f7'); repo=root/'repo'; logs=root/'logs'; logs.mkdir(exist_ok=True)
ev=root/'events.jsonl'
def run(name,cmd,cwd=None,extra=None):
 start=time.time(); rec={'event':'command_execution','name':name,'argv':cmd,'cwd':str(cwd or root),'start':start}; ev.open('a').write(json.dumps(rec)+'\n')
 with (logs/(name+'.log')).open('w') as f:
  p=subprocess.run(cmd,cwd=cwd or root,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,**(extra or {})})
 rec.update(exit=p.returncode,elapsed=round(time.time()-start,2),log=str(logs/(name+'.log'))); ev.open('a').write(json.dumps(rec)+'\n'); print(json.dumps(rec),flush=True); return p.returncode
if not repo.exists():
 if run('clone',['git','clone','--no-checkout','https://github.com/SammySnake-d/g-group.git',str(repo)]): raise SystemExit(2)
if run('checkout',['git','checkout','-b','feat/desktop-closed-loop','cb9f13e00f5ac36f6bfea47d9f4c37d0ce9398ed'],repo): raise SystemExit(2)
run('version',['node','--version'],repo)
run('freeze',['git','rev-parse','HEAD','origin/feat/desktop-files-provenance'],repo)
if run('install',['npm','ci','--no-audit','--no-fund'],repo): raise SystemExit(2)
env={'GATE_SELFTEST_JOBS':'2','GATE_MUTATION_JOBS':'2'}

app=repo/'apps/desktop'
if run('install-desktop',['npm','ci','--no-audit','--no-fund'],app): raise SystemExit(2)
env.update({'GG_PW_PORT':'5275','GG_SHOTS':str(root/'shots'),'DISPLAY':':0'})
run('typecheck-desktop',['npm','run','typecheck'],app,env)
run('structure',['npm','run','verify:structure'],app,env)
if run('build',['npm','run','build'],app,env): raise SystemExit(2)
# 使用已安装 Chrome,遵循项目不下载浏览器内核的约定
run('chrome',['sh','-c','command -v google-chrome || command -v google-chrome-stable || command -v chromium'],app)
run('renderer',['xvfb-run','-a','npm','run','e2e'],app,env)
run('electron',['xvfb-run','-a','npm','run','e2e:electron'],app,env)
run('freeze-end',['git','status','--short'],repo)
(root/'ui-done.json').write_text(json.dumps({'done':True,'finished':time.time()})+'\n')
