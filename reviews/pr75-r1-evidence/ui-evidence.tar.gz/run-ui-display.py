import pathlib,subprocess,os,json,time
root=pathlib.Path('/workspace/pr75-r1-ui-codex-5c7730f7'); app=root/'repo/apps/desktop'; logs=root/'logs'
env={**os.environ,'GG_PW_PORT':'5275','GG_SHOTS':str(root/'shots'),'DISPLAY':':0'}
for name,args in [('renderer-display',['npm','run','e2e']),('electron-display',['npm','run','e2e:electron'])]:
 rec={'event':'command_execution','name':name,'argv':args,'start':time.time()}; (root/'events.jsonl').open('a').write(json.dumps(rec)+'\n')
 with (logs/(name+'.log')).open('w') as f: p=subprocess.run(args,cwd=app,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec['exit']=p.returncode; rec['elapsed']=time.time()-rec['start']; (root/'events.jsonl').open('a').write(json.dumps(rec)+'\n'); print(json.dumps(rec),flush=True)
(root/'ui-display-done.json').write_text(json.dumps({'done':True,'finished':time.time()})+'\n')
