import pathlib,subprocess,os,json,time
root=pathlib.Path('/workspace/pr75-r1-r7-codex-5c7730f7');root.mkdir(exist_ok=True)
repo=pathlib.Path('/workspace/pr75-r1-codex-5c7730f7/repo')
groups=','.join(map(str,sorted(set(os.getgroups()+[int(subprocess.check_output(['stat','-c','%g','/var/run/docker.sock'],text=True))]))))
cmd=['sudo','-n','setpriv','--reuid='+str(os.getuid()),'--regid='+str(os.getgid()),'--groups='+groups,'env','GATE_SANDBOX_IMAGE=node:22.22.0-slim','GATE_SELFTEST_ONLY=R7-01 沙箱按实际 HOME','GATE_SELFTEST_JOBS=1','npm','run','gates:selftest']
r={'event':'command_execution','argv':cmd,'start':time.time()}
(root/'event.json').write_text(json.dumps(r)+'\n')
with (root/'r7.log').open('w') as f:p=subprocess.run(cmd,cwd=repo,env=os.environ.copy(),stdout=f,stderr=subprocess.STDOUT)
r.update(exit=p.returncode,elapsed=time.time()-r['start']);(root/'event.json').write_text(json.dumps(r)+'\n');print(json.dumps(r))
