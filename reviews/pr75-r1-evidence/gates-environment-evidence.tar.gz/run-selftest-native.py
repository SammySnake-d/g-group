import pathlib,subprocess,os,json,time
root=pathlib.Path('/workspace/pr75-r1-gates-codex-5c7730f7'); repo=root/'repo'; logs=root/'logs'
base={**os.environ,'GATE_SANDBOX_IMAGE':'node:22.22.0-slim','GATE_SELFTEST_JOBS':'2','GATE_MUTATION_JOBS':'1'}
uid=str(os.getuid()); gid=str(os.getgid()); dg=subprocess.check_output(['stat','-c','%g','/var/run/docker.sock'],text=True).strip(); groups=','.join(map(str,sorted(set(os.getgroups()+[int(dg)]))))
for name,args in [('selftest-native-group',['npm','run','gates:selftest'])]:
 cmd=['sudo','-n','setpriv','--reuid='+uid,'--regid='+gid,'--groups='+groups,'env','GATE_SANDBOX_IMAGE=node:22.22.0-slim','GATE_SELFTEST_JOBS=2',*args]
 rec={'event':'command_execution','name':name,'argv':cmd,'start':time.time()}; (root/'events.jsonl').open('a').write(json.dumps(rec)+'\n')
 with (logs/(name+'.log')).open('w') as f: p=subprocess.run(cmd,cwd=repo,env=base,stdout=f,stderr=subprocess.STDOUT)
 rec['exit']=p.returncode; rec['elapsed']=time.time()-rec['start']; (root/'events.jsonl').open('a').write(json.dumps(rec)+'\n'); print(json.dumps(rec),flush=True)
(root/'selftest-native-done.json').write_text(json.dumps({'done':True,'finished':time.time()})+'\n')
