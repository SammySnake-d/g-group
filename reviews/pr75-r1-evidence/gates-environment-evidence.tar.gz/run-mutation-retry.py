import pathlib,subprocess,os,json,time
root=pathlib.Path('/workspace/pr75-r1-gates-codex-5c7730f7'); repo=root/'repo'; logs=root/'logs'
env={**os.environ,'GATE_SANDBOX_IMAGE':'node:22.22.0-slim','GATE_SELFTEST_JOBS':'1','GATE_MUTATION_JOBS':'1','PATH':str(root/'bin')+':'+os.environ['PATH']}
# 保留上一轮 DNS 错误;镜像现存时直接用版本化官方镜像,无需再拉。
for name,args in [('docker-image-verify',['docker','image','inspect','node:22.22.0-slim','--format','{{.Id}}']),('docker-version-verify',['docker','run','--rm','--network','none','node:22.22.0-slim','node','--version']),('gates-mutation-retry',['npm','run','gates:mutation'])]:
 rec={'event':'command_execution','name':name,'argv':args,'start':time.time()}; (root/'events.jsonl').open('a').write(json.dumps(rec)+'\n')
 with (logs/(name+'.log')).open('w') as f: p=subprocess.run(args,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
 rec['exit']=p.returncode; rec['elapsed']=time.time()-rec['start']; (root/'events.jsonl').open('a').write(json.dumps(rec)+'\n'); print(json.dumps(rec),flush=True)
 if p.returncode and name!='gates-mutation-retry': raise SystemExit(2)
(root/'mutation-retry-done.json').write_text(json.dumps({'done':True,'finished':time.time()})+'\n')
