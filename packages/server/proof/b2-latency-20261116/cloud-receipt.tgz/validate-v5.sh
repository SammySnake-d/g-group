#!/bin/sh
# 在新克隆验证固定候选；不覆盖前次红绿或失败日志。
set -u
root=/workspace/codex-g-group-b2-f9e26905
repo="$root/repo-v5"
echo "开始固定候选验证 v5"
flock -w 600 /workspace/.heavy.lock sh -c '
  set -u
  root="$1"; repo="$root/repo-v5"
  test ! -e "$repo" || exit 2
  git clone --quiet --shared "$root/repo-v2" "$repo" || exit 3
  cd "$repo" || exit 4
  git checkout --quiet --detach 45976fca3c1311451acf17c915509d724bf719f1 || exit 5
  test "$(git rev-parse HEAD)" = 45976fca3c1311451acf17c915509d724bf719f1 || exit 6
  npm ci --no-audit --no-fund > "$root/v5-install.log" 2>&1
  rc=$?; printf "%s\n" "$rc" > "$root/v5-install.exit"; test "$rc" -eq 0 || exit 7
  cp "$root/candidate-test-v5.ts" packages/server/src/reflect-parallel.test.ts || exit 8
  node --test --test-reporter=tap --test-name-pattern="^反思失败且本轮无笔记" packages/server/src/reflect-parallel.test.ts > "$root/v5-red.tap" 2>&1
  red=$?; printf "%s\n" "$red" > "$root/v5-red.exit"
  test "$red" -ne 0 && grep -q "反思未结束时后备就已启动" "$root/v5-red.tap" || exit 9
  git apply --check "$root/candidate-v5.patch" || exit 10
  git apply "$root/candidate-v5.patch" || exit 11
  sha256sum -c "$root/candidate-inputs-v5.sha256" > "$root/v5-hash.log" 2>&1 || exit 12
  node --test --test-reporter=tap --test-concurrency=1 packages/server/src/reflect-parallel.test.ts packages/server/src/state-note.test.ts packages/server/src/memory.test.ts packages/adapter-pi-contact/src/compact.test.ts > "$root/v5-scope.tap" 2>&1
  rc=$?; printf "%s\n" "$rc" > "$root/v5-scope.exit"; test "$rc" -eq 0 || exit 13
  npm run typecheck > "$root/v5-typecheck.log" 2>&1
  rc=$?; printf "%s\n" "$rc" > "$root/v5-typecheck.exit"; test "$rc" -eq 0 || exit 14
  ./node_modules/.bin/biome lint --error-on-warnings packages/kernel/src/runtime-ports.ts packages/adapter-pi-contact/src/compact.ts packages/adapter-pi-contact/src/compact.test.ts packages/server/src/host.ts packages/server/src/reflect-parallel.test.ts > "$root/v5-lint.log" 2>&1
  rc=$?; printf "%s\n" "$rc" > "$root/v5-lint.exit"; test "$rc" -eq 0 || exit 15
  node scripts/gates/test-runner.ts --test-concurrency=1 "packages/**/*.test.ts" "scripts/gates/*.test.ts" > "$root/v5-full.tap" 2>&1
  rc=$?; printf "%s\n" "$rc" > "$root/v5-full.exit"; test "$rc" -eq 0 || exit 16
  echo "候选验证完成"
' sh "$root"
rc=$?
printf '%s\n' "$rc" > "$root/validate-v5.exit"
echo "验证退出码：$rc"
exit "$rc"
