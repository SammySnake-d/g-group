#!/usr/bin/env python3
"""独立核对作者变异清单产生的逐项 TAP；不运行、不改写产品或变异。"""
import argparse, collections, json, pathlib, re
p=argparse.ArgumentParser()
p.add_argument('tap_dir',type=pathlib.Path)
p.add_argument('--expected-tests',type=int,default=116)
p.add_argument('--ids',default=','.join(f'M{i:02d}' for i in range(1,167)))
p.add_argument('--output',type=pathlib.Path)
a=p.parse_args(); ids=a.ids.split(',')
summary_re=re.compile(r'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)\s*$',re.M)
line_re=re.compile(r'^(not ok|ok) \d+ - (.+)$',re.M)
def load(name,clean=False):
    tap=a.tap_dir/(name+'.tap'); meta=a.tap_dir/(name+'.json')
    if not tap.exists() or not meta.exists(): return {'id':name,'state':'missing'}
    text=tap.read_text(errors='replace'); info=json.loads(meta.read_text()); summary={k:int(v) for k,v in summary_re.findall(text)}
    lines=list(line_re.finditer(text)); passed=[m[2] for m in lines if m[1]=='ok']; failed=[m[2] for m in lines if m[1]=='not ok']; reasons=[]; problems=[]
    if not re.search(r'^1\.\.'+str(a.expected_tests)+r'$',text,re.M): problems.append('计划数不符')
    for k in ['tests','pass','fail','cancelled','skipped','todo']:
        if k not in summary: problems.append('缺少汇总:'+k)
    if summary.get('tests')!=a.expected_tests: problems.append('测试总数不符')
    for k in ['cancelled','skipped','todo']:
        if summary.get(k)!=0: problems.append(k+' 非零或缺失')
    if info.get('signal') is not None or info.get('timedOut') is not False: problems.append('信号或超时')
    if info.get('code')!=(0 if clean else 1): problems.append('退出码不符')
    if len(lines)!=a.expected_tests or summary.get('pass')!=len(passed) or summary.get('fail')!=len(failed): problems.append('具名结果与汇总不符')
    if clean and failed: problems.append('原样副本有失败')
    if not clean and not failed: problems.append('没有具名失败')
    for i,m in enumerate(lines):
        if m[1]!='not ok':continue
        next_sub=text.find('\n# Subtest:',m.end());next_line=lines[i+1].start() if i+1<len(lines) else len(text); stop=min(x for x in [next_line,next_sub if next_sub>=0 else len(text)])
        detail=text[m.end():stop]; reason=re.search(r"failureType:\s*['\"]([^'\"]+)",detail)
        kind=reason.group(1) if reason else 'missing';reasons.append({'test':m[2],'failureType':kind})
        if kind!='testCodeFailure':problems.append('失败原因非正常测试代码失败:'+m[2][:120]+' ['+kind+']')
    if any(re.search(r'\s#\s*(?:SKIP|TODO)\b', m[2], re.I) for m in lines): problems.append('结果行有跳过或待办')
    if len(set(m[2] for m in lines)) != len(lines): problems.append('重复测试名')
    return {'id':name,'state':'invalid' if problems else 'ok','summary':summary,'problems':problems,'names':passed+failed,'failures':reasons,'code':info.get('code')}
base=load('clean',True); base_names=collections.Counter(base.get('names',[])); out=[]
for id in ids:
    row=load(id)
    if row['state']!='missing' and base_names and collections.Counter(row.get('names',[]))!=base_names:
        row['problems'].append('具名测试集合与原样副本不一致');row['state']='invalid'
    out.append(row)
counts=collections.Counter(r['state'] for r in out)
result={'expected_tests':a.expected_tests,'baseline':base,'counts':dict(counts),'complete':base['state']=='ok' and counts.get('ok',0)==len(ids),'mutants':out}
if a.output:a.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('基线:',base['state'],'变异:',dict(counts),'要求:',len(ids),'完整:',result['complete'])
for r in [base,*out]:
 if r['state']=='invalid':print(r['id'],'; '.join(r['problems']))
