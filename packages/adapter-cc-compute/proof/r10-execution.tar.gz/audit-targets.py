import json,re,sys,pathlib
base=pathlib.Path(sys.argv[1]);targets=json.loads(pathlib.Path(sys.argv[2]).read_text());results=[]
for id,t in targets.items():
 p=base/(id+'.tap')
 if not p.exists():results.append({'id':id,'matched':False,'reason':'missing'});continue
 matched=[]
 for block in re.split(r'^# Subtest: ',p.read_text(),flags=re.M)[1:]:
  m=re.search(r'^not ok \d+ - (.+)$',block,re.M)
  if not m or m[1]!=t['name']:continue
  def val(k):
   r=re.search(r'^  '+k+r''': ['"]([^'"\n]+)['"]$''',block,re.M)
   return r[1] if r else None
  same=val('failureType')=='testCodeFailure' and val('code')==t['code'] and (not t.get('errorName') or val('name')==t['errorName'])
  matched.append({'matched':same,'code':val('code'),'errorName':val('name'),'failureType':val('failureType')})
 results.append({'id':id,'target':t['name'],'matched':len(matched)==1 and matched[0]['matched'],'observed':matched})
out={'expected':len(targets),'matched':sum(r['matched'] for r in results),'complete':all(r['matched'] for r in results),'results':results}
print(json.dumps(out,ensure_ascii=False,indent=2))
sys.exit(0 if out['complete'] else 1)
