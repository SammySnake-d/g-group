#!/bin/sh
cd /workspace/pr7-r12-astra || exit 1
# 输入在整个运行期间固定，不改源码、配置或判决器。
git checkout -f e2722ed || exit 1
npm run -s typecheck > evidence-r12/red-accept-types.log 2>&1
echo $? > evidence-r12/red-accept-types.exit
node --test --test-reporter=tap packages/adapter-cc-compute/src/*.test.ts > evidence-r12/red-accept.tap 2>&1
echo $? > evidence-r12/red-accept.exit
git checkout -f feat/cc-compute || exit 1
git rev-parse HEAD > evidence-r12/frozen-head.txt
npm run -s typecheck > evidence-r12/accept-types.log 2>&1
echo $? > evidence-r12/accept-types.exit
npm run -s lint > evidence-r12/accept-lint.log 2>&1
echo $? > evidence-r12/accept-lint.exit
node --test --test-reporter=tap 'packages/**/*.test.ts' > evidence-r12/accept-all.tap 2>&1
echo $? > evidence-r12/accept-all.exit
TMPDIR=/workspace/pr7-r12-astra/evidence-r12/tmp CC_MUT_CONCURRENCY=2 CC_MUT_EVIDENCE=/workspace/pr7-r12-astra/evidence-r12/mutations CC_MUT_PROGRESS=/workspace/pr7-r12-astra/evidence-r12/mutation-progress.log node packages/adapter-cc-compute/proof/mutations.mjs > evidence-r12/mutations.log 2>&1
echo $? > evidence-r12/mutations.exit
printf '已结束\n' > evidence-r12/verify.done
