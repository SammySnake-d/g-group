#!/bin/sh
cd /workspace/pr7-r12-astra || exit 1
npm run -s typecheck > evidence-r12/bounded-types.log 2>&1
echo $? > evidence-r12/bounded-types.exit
npm run -s lint > evidence-r12/bounded-lint.log 2>&1
echo $? > evidence-r12/bounded-lint.exit
node --test --test-reporter=tap 'packages/**/*.test.ts' > evidence-r12/bounded-all.tap 2>&1
echo $? > evidence-r12/bounded-all.exit
git rev-parse HEAD > evidence-r12/frozen-head-bounded.txt
export TMPDIR=/workspace/pr7-r12-astra/evidence-r12/tmp
export CC_MUT_CONCURRENCY=2
export CC_MUT_EVIDENCE=/workspace/pr7-r12-astra/evidence-r12/mutations
export CC_MUT_PROGRESS=/workspace/pr7-r12-astra/evidence-r12/mutation-progress.log
export CC_MUT_ONLY=M13,M167,M168,M169,M170,M171,M172,M173,M174,M175,M176,M177
node packages/adapter-cc-compute/proof/mutations.mjs > evidence-r12/calibration.log 2>&1
code=$?
echo "$code" > evidence-r12/calibration.exit
for ext in tap json stderr; do cp "evidence-r12/mutations/clean.$ext" "evidence-r12/calibration-clean.$ext"; done
if [ "$code" != 0 ]; then exit "$code"; fi
export CC_MUT_ONLY=$(node --input-type=module -e 'console.log(Array.from({length:166},(_,i)=>i+1).filter(i=>i!==13).map(i=>"M"+String(i).padStart(2,"0")).join(","))')
node packages/adapter-cc-compute/proof/mutations.mjs > evidence-r12/mutations.log 2>&1
code=$?
echo "$code" > evidence-r12/mutations.exit
printf '已结束\n' > evidence-r12/verify.done
exit "$code"
