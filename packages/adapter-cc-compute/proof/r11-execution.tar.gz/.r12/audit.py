import pathlib,re,json,sys
root=pathlib.Path(sys.argv[1]);targets=json.loads(pathlib.Path('packages/adapter-cc-compute/proof/mutation-targets.json').read_text())
def parse(p):
 text=p.read_text();rows=list(re.finditer(r'^(ok|not ok) (\d+) - (.+)$',text,re.M));summ=dict((k,int(v)) for k,v in re.findall(r'^# (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)$',text,re.M));plan=re.findall(r'^1\.\.(\d+)$',text,re.M);names=[m[3] for m in rows];issues=[]
 if plan!=[str(len(rows))] or not rows:issues.append('计划')
 if [int(m[2]) for m in rows]!=list(range(1,len(rows)+1)):issues.append('顺序')
 if any(re.search(r'\s#\s*(SKIP|TODO)',n,re.I) for n in names):issues.append('指令')
 if any('/'==n[:1] or re.search(r'\.test\.[cm]?[jt]s$',n) for n in names):issues.append('文件失败')
 fails=[m[3] for m in rows if m[1]=='not ok']
 expected={'tests':len(rows),'suites':0,'pass':len(rows)-len(fails),'fail':len(fails),'cancelled':0,'skipped':0,'todo':0}
 if summ!=expected:issues.append('汇总')
 return text,rows,names,fails,issues
text,rows,names,fails,issues=parse(root/'mutations/clean.tap')
meta=json.loads((root/'mutations/clean.json').read_text())
assert not fails and not issues and meta=={'code':0,'signal':None,'timedOut':False},(fails,issues,meta)
results=[]
for id,t in targets.items():
 path=root/f'mutations/{id}.tap'
 if not path.exists():results.append({'id':id,'killed':False,'issues':['未运行']});continue
 text,rows,ns,fs,errors=parse(path);meta=json.loads((root/f'mutations/{id}.json').read_text())
 if meta!={'code':1,'signal':None,'timedOut':False}:errors.append('进程状态')
 if ns!=names:errors.append('名称集合顺序')
 ix=next((i for i,m in enumerate(rows) if m[3]==t['name']),None)
 if ix is None or rows[ix][1]!='not ok':errors.append('指定具名未失败')
 else:
  block=text[rows[ix].end():rows[ix+1].start() if ix+1<len(rows) else len(text)]
  for key,val in [('failureType','testCodeFailure'),('code',t['code']),('name',t.get('errorName'))]:
   if val is not None and not re.search(r'^\s+'+key+r": ['\"]?"+re.escape(val)+r"['\"]?\s*$",block,re.M):errors.append(key)
 results.append({'id':id,'killed':not errors,'issues':errors,'all_failed':fs})
output={'baseline_tests':len(names),'mutations':len(results),'killed':sum(r['killed'] for r in results),'not_killed':[r for r in results if not r['killed']],'results':results}
path=root/'independent-audit.json';path.write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in output.items() if k!='results'},ensure_ascii=False));sys.exit(0 if all(r['killed'] for r in results) else 1)
